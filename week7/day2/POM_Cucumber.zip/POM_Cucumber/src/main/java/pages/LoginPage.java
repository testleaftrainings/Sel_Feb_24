package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import basecucumber.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	


	@When("Enter the username as {string}")
	public LoginPage enterUserName(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		
		return this;
	}
	
	@And("Enter the password as {string}")
    public LoginPage enterPassWord(String passWord) {
		getDriver().findElement(By.id("password")).sendKeys(passWord);
		return this;
	}
    
	@And("Click on LoginButton")
    public HomePage clickOnLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}
	
	@Then("Hompage should be displayed")
	public HomePage verifyPage() {
		String title=getDriver().getTitle();
		if(title.contains("Automation ")) {
			System.out.println("Login  Successfull");
		}else {
			System.out.println("Login not Successful");
		}
		
		return new HomePage();
	}
}
