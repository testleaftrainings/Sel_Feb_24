package threadlocal;

public class Encapsulation {

	private String name;

	
	  public String getName() { 
		  return name; }
	  
	  public void setName(String name) { 
		  this.name = name; }
	 
}

//setter -it will set value from the variable
//getter - it will get value from the setter