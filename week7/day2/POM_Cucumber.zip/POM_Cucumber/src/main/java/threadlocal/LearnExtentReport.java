package threadlocal;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {

//		 * 1.Setup Physical report path 
//		 * 2.Create object for extentreports
//		 * 3.Attach data with physical file-combine step 1 & step 2
//		 * 4.Create a testcase and assigned test details 
//           i can give testcase name, testcase dcs,author name,category
//		 * 5.Steps level status 
//         pass
//         fail
//		 * 6.Mandatory step to stop.
//          close report
		
		//step -1
		ExtentHtmlReporter repo= new ExtentHtmlReporter("./result/report.html");
		
		//if you want to save existing result
		repo.setAppendExisting(true);
		
		//step -2
		ExtentReports exe=new ExtentReports();
		
		//step 3
		exe.attachReporter(repo);
		//tc-1
		//step 4
		ExtentTest test=exe.createTest("Login Page", "Login with positive data");
		test.assignAuthor("Dilip");
		test.assignCategory("Smoke");
		
		//step 5
		test.pass("Enter username", MediaEntityBuilder.createScreenCaptureFromPath(".././snap/snapshot.png").build());
	    test.pass("Enter password");
	    test.fail(" click on login button");
	    
	    
	    //step 6
	    exe.flush();
	    System.out.println("done");
	    
	    //tc-2
	    
//	    ExtentTest test1=exe.createTest("CreateLead");
//	    test1.assignAuthor("Aravind");
//	    test1.assignCategory("Sanity");
//	    
//	    test1.pass("Enter CompanyName");
//	    test1.pass("Enter Firstname");
//	    test1.pass("Enter Lastname");
	   
	}

}
