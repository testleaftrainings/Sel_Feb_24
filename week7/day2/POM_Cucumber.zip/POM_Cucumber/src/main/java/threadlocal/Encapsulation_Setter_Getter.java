package threadlocal;

public class Encapsulation_Setter_Getter {

	public static void main(String[] args) {
		Encapsulation e=new Encapsulation();
		
		e.setName("Cucumber");
		System.out.println(e.getName());
	}
	
	
}
