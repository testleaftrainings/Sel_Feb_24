package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import basecucumber.BaseClass;
import pages.LoginPage;

public class TC_001_Login extends BaseClass{

	//step -7
//	@BeforeTest
//	public void setData() {
//		filedata="LoginSheet";
//	}
	
	
	//step-5
	@Test
	
	public void login() {
		
		LoginPage lp=new LoginPage();
	
		lp.enterUserName("DemoCSR")
		.enterPassWord("crmsfa")
		.clickOnLoginButton();
		
		//.clickCrmsfa()
		//.clickLeads().clickOnCreateLead();
	}
	
}
